-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2022 at 05:40 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurantinfo`
--

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `itemName` text NOT NULL,
  `categoryId` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  `itemDescription` text NOT NULL,
  `itemPrice` float(10,2) NOT NULL,
  `itemImage` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`itemName`, `categoryId`, `itemId`, `itemDescription`, `itemPrice`, `itemImage`) VALUES
('Chicken Nuggets', 1, 1, 'Fried chicken bites, poultry seasoning, deep fat, eggs, and garlic salt.', 5.00, '../images/chicken/chicken-nuggets.jpg'),
('Spicy Wings', 1, 2, 'Hot sauce, fried chicken wings, cayenne pepper, batter and peanut.', 4.50, '../images/chicken/spicy-wings.jpg'),
('Crispy Fillet', 1, 3, 'Boneless chicken breasts, buttermilk, eggs, chili powder and garlic powder.', 4.75, '../images/chicken/crispy-fillet.jpg'),
('Los Pollos Fillet', 1, 4, 'Skinless chicken breast, parmesan cheese, olive oil, lemon juice, egg and los pollos hermanos.', 5.50, '../images/chicken/los-pollos-fillet.jpg'),
('Los Pollos Meal', 1, 5, 'Fried chicken wings, nuggets and a fillet accompanied by three dips of your choice.', 10.00, '../images/chicken/los-pollos-meal.jpg'),
('Beef Burger', 2, 6, 'Single beef patty, chunky lettuce, caramelized onions, bacon, cheese. ', 6.00, '../images/burgers/beef-burger.jpg'),
('Double Beef Burger', 2, 7, 'Double beef patties, double cheese, lettuce, tomato, los pollos classic sauce and raw onion. ', 8.00, '../images/burgers/double-beef-burger.jpg'),
('Chicken Burger', 2, 8, 'Fried chicken, bacon, cheese, lettuce, tomatoes and BBQ sauce. ', 6.00, '../images/burgers/chicken-burger.jpg'),
('Spicy Chicken Burger', 2, 9, 'Fried chicken, lettuce, caramelized onions, jalapeños, American cheese and sweet chili sauce.', 7.00, '../images/burgers/spicy-chicken-burger.jpg'),
('Los Pollos Burger', 2, 10, 'Single beef patty, smoked applewood cheese, grilled parma ham, barbecue sauce and crispy onions.', 8.00, '../images/burgers/los-pollos-burger.jpg'),
('Fries', 3, 11, 'Raw potato sticks, white vinegar and peanut oil.', 1.80, '../images/sides/fries.jpg'),
('Sweet Potatoes', 3, 12, 'Sweet potatoes, olive oil, cayenne pepper and sea salt.', 2.50, '../images/sides/sweet-potatoes.jpg'),
('Onion Rings', 3, 13, 'Onions, bread crumbs, egg, baking powder, seasoned salt and all purpose flour.', 1.80, '../images/sides/onion-rings.jpg'),
('Mozzarella Sticks', 3, 14, 'Mozzarella cheese sticks, bread crumbs, eggs, garlic salt and all purpose flour. Accompanied by garlic mayo sauce.', 0.80, '../images/sides/mozzarella-sticks.jpg'),
('Coleslaw', 3, 15, 'Carrots, onions and lettuce mixed lemon juice, vinegar, mayonnaise, white sugar and black pepper.', 1.90, '../images/sides/coleslaw.jpg'),
('Salad', 3, 16, 'Italian dressing, cherry tomatoes, green olives, red pepper flakes and feta cheese.\r\n', 2.00, '../images/sides/salad.jpg'),
('Mini Kievs', 3, 17, 'Ground chicken, eggs, garlic, flour and garlic butter.', 0.70, '../images/sides/mini-kievs.jpg'),
('Garlic Mayo', 4, 18, 'Olive oil, garlic, lemon juice and mayonnaise.', 0.45, '../images/dips/garlic-mayo.jpg'),
('BBQ Sauce', 4, 19, 'Brown sugar, malt vinegar, Worcestershire sauce, tomato and olive oil.', 0.45, '../images/dips/bbq-sauce.jpg'),
('Sweet Chili', 4, 20, 'Gluten free soy, sambal oelek, rice vinegar, cayenne pepper and white sugar.', 0.45, '../images/dips/sweet-chili.jpg'),
('Sweet and Sour', 4, 21, 'Apple cider vinegar, canned pineapple juice, soy sauce, brown sugar and red food coloring.', 0.45, '../images/dips/sweet-and-sour.jpg'),
('Los Pollos Classic', 4, 22, 'Red pepper flakes, lemon juice, garlic, sea salt, black pepper and our secret ingredient.', 0.50, '../images/dips/los-pollos-classic.jpg'),
('Doughnut', 5, 23, 'Powdered sugar, eggs, active dry yeast, all purpose flour, sprinkles, chocolate and whole milk.', 2.50, '../images/desserts/doughnut.jpg'),
('Chocolate Muffin', 5, 24, 'Cocoa powder, self raising flour, olive oil, milk, sugar and chocolate chips.', 2.50, '../images/desserts/chocolate-muffin.jpg'),
('Double Chocolate Cookie', 5, 25, 'Brown sugar, chocolate chips, white, eggs, baking soda and chocolate.', 2.00, '../images/desserts/double-chocolate-cookie.jpg'),
('Still Water', 6, 26, 'Life starts with water.', 1.00, '../images/beverages/still-water.jpg'),
('Sparkling Water', 6, 27, 'Sparkling fresh.', 1.20, '../images/beverages/sparkling-water.jpg'),
('Coke', 6, 28, 'Real Magic.', 1.75, '../images/beverages/coke.jpg'),
('Sprite', 6, 29, 'Obey Your Thirst.', 1.75, '../images/beverages/sprite.jpg'),
('Fanta', 6, 30, 'Be More Than One Flavour.', 1.75, '../images/beverages/fanta.jpg'),
('Cisk', 6, 31, 'Fancy a Cisk?', 2.00, '../images/beverages/cisk.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `store_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`store_id`, `address`) VALUES
(1, 'Mdina Rd, Haz-Zebbug ZBG 9016'),
(2, 'Triq il-Gardiel, Marsaskala MSK 3381'),
(3, 'Tal-Barrani Road, Żejtun ZJT 8008');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `categoryID` int(11) NOT NULL,
  `categoryName` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`categoryID`, `categoryName`) VALUES
(1, 'Chicken'),
(2, 'Burgers'),
(3, 'Sides'),
(4, 'Dips'),
(5, 'Desserts'),
(6, 'Beverages');

-- --------------------------------------------------------

--
-- Table structure for table `opening_hours`
--

CREATE TABLE `opening_hours` (
  `id` int(11) NOT NULL,
  `day` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `opening_hours`
--

INSERT INTO `opening_hours` (`id`, `day`, `time`) VALUES
(1, 'Monday', '07:00 - 23:00'),
(2, 'Tuesday', '07:00 - 23:00'),
(3, 'Wednesday', '07:00 - 23:00'),
(4, 'Thursday', '07:00 - 23:00'),
(5, 'Friday', '07:00 - 23:00'),
(6, 'Saturday', '07:00 - 13:00'),
(7, 'Sunday', 'Closed');

-- --------------------------------------------------------

--
-- Table structure for table `worker_info`
--

CREATE TABLE `worker_info` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `quote` varchar(255) NOT NULL,
  `period` int(11) NOT NULL,
  `pfp` varchar(255) NOT NULL,
  `alt_text` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `worker_info`
--

INSERT INTO `worker_info` (`id`, `name`, `position`, `quote`, `period`, `pfp`, `alt_text`) VALUES
(1, 'Gus Fring', 'Owner/Proprieter', '\"Hello and Welcome to the Los Pollos Hermanos family. My name is Gustavo, but you can call me Gus. Here at Los Pollos Hermanos, we take pride in serving some of the best food in the whole country.\"', 10, '../images/Worker1.png', 'Gus Fring Profile Picture'),
(2, 'Saul Goodman', 'Co-Owner', '\"I’m working harder than ever now, and I’m putting on my pants the same as I always have. I just get up every day and try to do a little better than the day before, and that is the secret to running a great restaurant.\"', 10, '../images/Worker2.png', 'Saul Goodman Profile Picture'),
(3, 'Isaac Ranger', 'Manager', '\"We see our customers as invited guests to a party, and we are the hosts. It’s our job every day to make every important aspect of the customer experience a little bit better.\"', 6, '../images/Worker3.png', 'Isaac Ranger Profile Picture');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`itemId`),
  ADD KEY `CategoryIdConstraint` (`categoryId`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`store_id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`categoryID`);

--
-- Indexes for table `opening_hours`
--
ALTER TABLE `opening_hours`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worker_info`
--
ALTER TABLE `worker_info`
  ADD PRIMARY KEY (`id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `CategoryIdConstraint` FOREIGN KEY (`categoryId`) REFERENCES `menu` (`categoryID`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
